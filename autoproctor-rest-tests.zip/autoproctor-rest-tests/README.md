## Getting Started

1. Download and install [IntelliJ IDEA](https://www.jetbrains.com/idea/download/). All instructions assume you'll be working with this IDE.
    > Skip if already installed.
2. Clone the Git project using IntelliJ IDEA:
   ```
   https://bitbucket.pearson.com/scm/opc/autoproctor-rest-tests.git
   ```
3. Import project as a Gradle project.
4. Run command from IntelliJ IDEA terminal: `gradlew clean build -x test`
    > Note: Mac users should use `./gradlew` in place of `gradlew`

## Configure Environment Under Test

##### From IDE: 
- Change ivs.environment found in `src/test/resources/configs/environment.property`

##### From Terminal: 
- Execute: `gradlew configureEnvironment -Penvironment.properties=<environment.properties>`

Possible ivs.environment values: `ST0, CTT or PRD`
<br/><br/>

## Test Execution
Execution from an IDE is self-explanatory. Instructions here are for running tests through terminal.

##### Run all tests: 
- Execute: `gradlew test`

##### Run class-level (suite) tests: 
- Execute: `gradlew test -P<className>`
    - Example: `gradlew test -PClientControllerTest`