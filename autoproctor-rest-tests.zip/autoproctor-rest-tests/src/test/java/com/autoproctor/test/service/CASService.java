package com.autoproctor.test.service;

import com.autoproctor.test.config.APSConfig;
import io.restassured.response.Response;
import org.testng.Assert;

import static io.restassured.RestAssured.given;

public class CASService {

    private CASService() {
    }

    public static Response getTokenResponse(APSConfig apsConfig){
        return given()
                .formParam("client_id", apsConfig.getClientId())
                .formParam("client_secret", apsConfig.getclientSecret())
                .formParam("grant_type", apsConfig.getgrantType())
                .formParam("certurl", apsConfig.getCerturl())
                .formParam("envpassword", apsConfig.getEnvpassword())
                .formParam("sessionTableURL", apsConfig.getsessionTableURL())
                .formParam("sensorEventTableURL", apsConfig.getsensorEventTableURL())
                .post(apsConfig.getcasToken());
    }

    public static String getToken(APSConfig apsConfig){
        final Response tokenResponse = getTokenResponse(apsConfig);
        final String token = tokenResponse.jsonPath().get("access_token");
        Assert.assertEquals(tokenResponse.getStatusCode(), 200);
        System.out.println(tokenResponse.jsonPath().prettify());
        return token;
    }
}
