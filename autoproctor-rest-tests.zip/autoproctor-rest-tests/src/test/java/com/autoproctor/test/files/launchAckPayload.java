package com.autoproctor.test.files;

import com.autoproctor.test.validation.StartAndEndExamTest;

public class launchAckPayload {
    public static  String  Payload () {
        String sensorIDCopy;
        sensorIDCopy = StartAndEndExamTest.useItemSensorId;
        return "{\n" +
                "    \"sensorId\": \""+sensorIDCopy+"\",\n" +
                "\"status\":\"SUCCESS\"\n" +
                "}";
    }
}
