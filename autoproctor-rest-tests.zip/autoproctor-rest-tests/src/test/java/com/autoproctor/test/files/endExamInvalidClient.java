package com.autoproctor.test.files;

import java.util.UUID;

public class endExamInvalidClient {
    public static  String  Payload () {
        String reservationAsString;
        reservationAsString = startExamWithNoClientcodeConfigured.reservation1.toString();
        return "{\n" +
                "\"reservationId\":\""+reservationAsString+"\",\n" +
                "\"onVueSessionId\":37621,\n" +
                "\"examSeriesCode\":\"ABC\",\n" +
                "\"clientCode\":\"APSAutomation\"\n" +
                "}";
    }
}
