package com.autoproctor.test.files;

import com.autoproctor.test.validation.StartAndEndExamTest;

public class errornotificationBackendPayload102 {
    public static String Payload() {
        String sensorIDCopy;
        sensorIDCopy = StartAndEndExamTest.useGlobalSensorId;
        return "{\n" +
                "    \"sensorId\": \""+sensorIDCopy+"\",\n" +
                "   \"eventTime\":1617645201,\n" +
                "   \"notificationLevel\":\"ERROR\",\n" +
                "   \"code\":\"102\",\n" +
                "   \"description\":\"message\",\n" +
                "   \"data\":[{\n" +
                "    \"id\":\"FrameResolution\",\n" +
                "    \"value\":\"sampleRes\"\n" +
                "   }]\n" +
                "}";
    }
}
