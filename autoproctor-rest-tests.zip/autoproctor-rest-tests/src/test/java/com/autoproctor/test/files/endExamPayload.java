package com.autoproctor.test.files;

import java.util.UUID;
public class endExamPayload {

    public static  String  Payload () {
        String reservationAsString;
        reservationAsString = startExamPayload.reservation.toString();
                 return "{\n" +
                "\"reservationId\":\""+reservationAsString+"\",\n" +
                "\"onVueSessionId\":37622,\n" +
                "\"examSeriesCode\":\"2234518\",\n" +
                "\"clientCode\":\"HEWPACK\"\n" +
                "}";
    }
}
