package com.autoproctor.test.files;
public class sensorUnMutePayload {
    public static String Payload() {
        String reservationAsString;
        reservationAsString = startExamPayload.reservation.toString();
         return "{\n" +
                 "\"reservationId\":\"" + reservationAsString + "\",\n" +
                 "    \"onVueSessionId\": 37621,\n" +
                 "    \"eventType\": \"NO_FACE\",\n" +
                 "    \"state\": \"UNMUTE\"\n" +
                 "}";
    }
}
