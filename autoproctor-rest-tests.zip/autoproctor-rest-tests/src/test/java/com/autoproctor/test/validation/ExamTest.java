package com.autoproctor.test.validation;

import com.autoproctor.test.config.APSConfig;
import com.autoproctor.test.files.endExamPayload;
import com.autoproctor.test.files.errornotificationBackendPayload101;
import com.autoproctor.test.files.errornotificationBackendPayload102;
import com.autoproctor.test.files.invalidSensorIdPayload;
import com.autoproctor.test.files.launchAckPayload;
import com.autoproctor.test.files.notificationPayload;
import com.autoproctor.test.files.sensorMultiFaceEventStartPayload;
import com.autoproctor.test.files.sensorMultiFaceEventStopPayload;
import com.autoproctor.test.files.sensorMutePayload;
import com.autoproctor.test.files.sensorNoFaceEventStartPayload;
import com.autoproctor.test.files.sensorNoFaceEventStopPayload;
import com.autoproctor.test.files.sensorPausePayload;
import com.autoproctor.test.files.sensorResumePayload;
import com.autoproctor.test.files.sensorUnMutePayload;
import com.autoproctor.test.files.startExamPayload;
import com.autoproctor.test.files.startExamWithNoClientcodeConfigured;
import com.autoproctor.test.service.APSService;
import com.autoproctor.test.service.CASService;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONArray;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.oauth2;
import static io.restassured.RestAssured.requestSpecification;

public class ExamTest {
    RequestSpecification startExamres1;
    Response startExamresponse;
    RequestSpecification endExamres1;
    Response endExamresponse;
    RequestSpecification notificationRequest;
    Response notificationResponse;
    Response getSessionResponse;
    RequestSpecification getSessionRequest;

    RequestSpecification startExamRequest;
    RequestSpecification endExamRequest;
    Response tokenResponse;
    Response sessionResponse;
    Response smartreviewSensorEventResponse;
    String sensorId = "blah";
    String endpoint = "/rest/sensor/notification";
    RequestSpecification sensorEventRequest;
    RequestSpecification sensorEvent1;
    Response sensorEventResponse;
    Response sensorEventInvalidResponse;
    RequestSpecification sensorEventLaunchAckRequest;
    RequestSpecification sensorEventLaunchAck;
    Response sensorEventLaunchAckResponse;
    RequestSpecification sensorEventShutdownAckRequest;
    RequestSpecification sensorEventShutdownAck;
    Response sensorEventShutdownAckResponse;
    RequestSpecification sensorPauseEventRequest;
    RequestSpecification sensorPauseEventRequest1;
    Response sensorPauseEventResponse;
    RequestSpecification sensorResumeEventRequest;
    RequestSpecification sensorResumeEventRequest1;
    Response sensorResumeEventResponse;
    RequestSpecification sensorMuteEventRequest;
    RequestSpecification sensorMuteEventRequest1;
    Response sensorMuteEventResponse;
    RequestSpecification sensorunMuteEventRequest;
    RequestSpecification sensorunMuteEventRequest1;
    Response sensorunMuteEventResponse;
    RequestSpecification backendSensor_102_Request;
    RequestSpecification backendSensor_102_Request1;
    Response backendSensor_102_Response;
    RequestSpecification backendSensor_101_Request;
    RequestSpecification backendSensor_101_Request1;
    Response backendSensor_101_Response;
    RequestSpecification blacklistClientRequest;
    RequestSpecification blacklistClientRequest1;
    Response blacklistClientResponse;
    Response sessionResponse1;



    public static String useGlobalSensorId;
    public static String useItemSensorId;
    public static String reservationAsString;
    public static String reservationAsString1;

    private String token;
    private APSService apsService;
    private APSConfig apsConfig;

    @BeforeTest
    public void setUp() {
        apsConfig = new APSConfig();
        // Set up token credentials
        token = CASService.getToken(apsConfig);
        apsService = new APSService(apsConfig,token);
        startExamRequest = new RequestSpecBuilder().setBaseUri(apsConfig.getbaseUrl())
                .setAuth(oauth2(token)).setContentType("application/json").build();

    }

    //Start the exam with valid payload request
    @Test(priority=1)
    public void startExam_Validation_with_Success_200() throws InterruptedException {
        try {
        Response startExamresponse = apsService.startExam(startExamPayload.Payload());
        System.out.println(startExamresponse.asString());
        Assert.assertEquals(startExamresponse.getStatusCode(), 200);
        Thread.sleep(5000);
    } catch (Exception e) {
        System.out.println ("Test failed " + e);
    }
    }

    // Get the session table record entry using valid reservation id and session id
    @Test (priority=2)
    public void sessionTableValidation_with_Success_200() {
        try {
        Thread.sleep(10000);
        // call reservation id from start exam Payload
        reservationAsString = startExamPayload.reservation.toString();
        // User called reservation id to fetch the Get API
        sessionResponse = given().spec(startExamRequest).contentType(ContentType.JSON).when().get(apsConfig.getsessionTableURL()+reservationAsString)
                .then()
                .extract()
                .response();
        String responseString = sessionResponse.asString();
        System.out.println(responseString);
        Assert.assertEquals(sessionResponse.getStatusCode(), 200);
        Assert.assertEquals(reservationAsString, sessionResponse.jsonPath().getString("reservationId"));
        Assert.assertEquals("37621", sessionResponse.jsonPath().getString("onVueSessionId"));
        Assert.assertEquals("HEWPACK", sessionResponse.jsonPath().getString("clientCode"));
        Assert.assertEquals("2234517", sessionResponse.jsonPath().getString("examSeriesCode"));
        Assert.assertEquals("SampleID", sessionResponse.jsonPath().getString("clientCandidateId"));
        Assert.assertEquals("USA", sessionResponse.jsonPath().getString("demographicsCountry"));
        Assert.assertEquals("MN", sessionResponse.jsonPath().getString("demographicsState"));
        Assert.assertEquals("9aea40ce_stream1", sessionResponse.jsonPath().getString("webRtcStreamName"));
        Assert.assertEquals("app-b43X3PBH", sessionResponse.jsonPath().getString("webRtcApplicationName"));
        Assert.assertEquals("FACE_SENSOR", sessionResponse.jsonPath().getString("sessionSensorList[0].sensorName"));
        Assert.assertEquals("LAUNCH_FAIL", sessionResponse.jsonPath().getString("sessionSensorList[0].sensorStatus"));
        Assert.assertEquals("ITEM_SENSOR", sessionResponse.jsonPath().getString("sessionSensorList[1].sensorName"));
        Assert.assertEquals("LAUNCH_FAIL", sessionResponse.jsonPath().getString("sessionSensorList[1].sensorStatus"));
        useGlobalSensorId = sessionResponse.jsonPath().getString("sessionSensorList[0].sensorID");
        useItemSensorId = sessionResponse.jsonPath().getString("sessionSensorList[1].sensorID");
        System.out.println(useGlobalSensorId);
        System.out.println(useItemSensorId);
        System.out.println(reservationAsString);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }

    // Get the session_sensor table record entry using valid reservation id and session id
    @Test (priority=3)
    public void sessionSensor_TableValidation_with_Success_200() {
        try {
        reservationAsString = startExamPayload.reservation.toString();
        sessionResponse = given().spec(startExamRequest).contentType(ContentType.JSON).when().get(apsConfig.getsessionTableURL()+reservationAsString)
                .then()
                .extract()
                .response();
        String responseString = sessionResponse.asString();
        System.out.println(responseString);
        Assert.assertEquals(sessionResponse.getStatusCode(), 200);
        Assert.assertEquals(useGlobalSensorId, sessionResponse.jsonPath().getString("sessionSensorList[0].sensorID"));
        Assert.assertEquals("FACE_SENSOR", sessionResponse.jsonPath().getString("sessionSensorList[0].sensorName"));
        Assert.assertEquals("LAUNCH_FAIL", sessionResponse.jsonPath().getString("sessionSensorList[0].sensorStatus"));
        Assert.assertEquals(useItemSensorId, sessionResponse.jsonPath().getString("sessionSensorList[1].sensorID"));
        Assert.assertEquals("ITEM_SENSOR", sessionResponse.jsonPath().getString("sessionSensorList[1].sensorName"));
        Assert.assertEquals("LAUNCH_FAIL", sessionResponse.jsonPath().getString("sessionSensorList[1].sensorStatus"));
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }


    // Start event with launch sensor API with valid sensor id with status code 200 - No Face Event
    @Test (priority=3)
    public void launch_Sensor_noFace_event_Start_success_200() {
        try {
        sensorEvent1 = given().spec(sensorEventRequest).body(sensorNoFaceEventStartPayload.Payload());
        sensorEventResponse = sensorEvent1.when().post("/rest/sensor/event/").
                then().extract().response();
        String responseString = sensorEventResponse.asString();
        System.out.println(responseString);
        Assert.assertEquals(sensorEventResponse.getStatusCode(), 200);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }

    // Stop event with launch sensor API with valid sensor id with status code 200   - No Face Event
    @Test (priority=3)
    public void launch_Sensor_noFace_event_Stop_success_200() {
        try {
        sensorEvent1 = given().spec(sensorEventRequest).body(sensorNoFaceEventStopPayload.Payload());
        sensorEventResponse = sensorEvent1.when().post("/rest/sensor/event/").
                then().extract().response();
        String responseString = sensorEventResponse.asString();
        System.out.println(responseString);
        Assert.assertEquals(sensorEventResponse.getStatusCode(), 200);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }


    // Pause sensor test scenario when the sensor launches
    @Test (priority=4)
    public void pause_Sensor_event_success_200() {
        try {
            sensorPauseEventRequest1 = given().spec(sensorPauseEventRequest).body(sensorPausePayload.Payload());
            sensorPauseEventResponse = sensorPauseEventRequest1.when().post("/rest/exam/pausesensor").
                    then().extract().response();
            String responseString = sensorPauseEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorPauseEventResponse.getStatusCode(), 200);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }
    // Start event when the Sensor Paused - It should not create the event
    @Test (priority=5)
    public void launch_Sensor_noFace_event_Start() {
        try {
            sensorEvent1 = given().spec(sensorEventRequest).body(sensorNoFaceEventStartPayload.Payload());
            sensorEventResponse = sensorEvent1.when().post("/rest/sensor/event/").
                    then().extract().response();
            String responseString = sensorEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorEventResponse.getStatusCode(), 200);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }

//    // Resume sensor test scenario when the sensor paused
    @Test (priority=6)
    public void resume_Sensor_event_success_200() {
        try {
            sensorResumeEventRequest1 = given().spec(sensorResumeEventRequest).body(sensorResumePayload.Payload());
            sensorResumeEventResponse = sensorResumeEventRequest1.when().post("/rest/exam/pausesensor").
                    then().extract().response();
            String responseString = sensorResumeEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorResumeEventResponse.getStatusCode(), 200);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }

    // Mute sensor test scenario when the sensor launches
    @Test (priority=7)
    public void mute_Sensor_event_success_200() {
        try {
            sensorMuteEventRequest1 = given().spec(sensorMuteEventRequest).body(sensorMutePayload.Payload());
            sensorMuteEventResponse = sensorMuteEventRequest1.when().post("/rest/exam/mutesensor/").
                    then().extract().response();
            String responseString = sensorMuteEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorMuteEventResponse.getStatusCode(), 200);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }
    // Start event when the Sensor Paused - It should not create the event
    @Test (priority=8)
    public void launch_Sensor_NoFace_Mute_event_Start() {
        try {
            sensorEvent1 = given().spec(sensorEventRequest).body(sensorNoFaceEventStartPayload.Payload());
            sensorEventResponse = sensorEvent1.when().post("/rest/sensor/event/").
                    then().extract().response();
            String responseString = sensorEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorEventResponse.getStatusCode(), 200);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }

//    // unMute sensor test scenario when the sensor Muted
    @Test (priority=9)
    public void unMute_Sensor_event_success_200() {
        try {
            sensorunMuteEventRequest1 = given().spec(sensorunMuteEventRequest).body(sensorUnMutePayload.Payload());
            sensorunMuteEventResponse = sensorunMuteEventRequest1.when().post("/rest/exam/mutesensor/").
                    then().extract().response();
            String responseString = sensorunMuteEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorunMuteEventResponse.getStatusCode(), 200);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }



    // Start event with launch sensor API with valid sensor id with status code 200 - Multi Face Event
    @Test (priority=3)
    public void launch_Sensor_multiFace_event_Start_success_200() {
        try {
            sensorEvent1 = given().spec(sensorEventRequest).body(sensorMultiFaceEventStartPayload.Payload());
            sensorEventResponse = sensorEvent1.when().post("/rest/sensor/event/").
                    then().extract().response();
            String responseString = sensorEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorEventResponse.getStatusCode(), 200);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }


    // Stop event with launch sensor API with valid sensor id with status code 200   - Multi Face Event Event
    @Test (priority=3)
    public void launch_Sensor_multiFace_event_Stop_success_200() {
        try {
        sensorEvent1 = given().spec(sensorEventRequest).body(sensorMultiFaceEventStopPayload.Payload());
        sensorEventResponse = sensorEvent1.when().post("/rest/sensor/event/").
                then().extract().response();
        String responseString = sensorEventResponse.asString();
        System.out.println(responseString);
        Assert.assertEquals(sensorEventResponse.getStatusCode(), 200);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }

    // Get the sensor_event_log table record entry from SmartReview database using valid reservation id and session id
    @Test (priority=10)
    public void smartReviewDB_senserEvent_log_TableValidation_with_Success_200() {
        try {
            reservationAsString = startExamPayload.reservation.toString();
            Thread.sleep(5000);
            smartreviewSensorEventResponse = given().contentType(ContentType.JSON).when().get(apsConfig.getsensorEventTableURL()+reservationAsString)
                    .then()
                    .extract()
                    .response();
            JSONArray responseArray = new JSONArray(smartreviewSensorEventResponse.asString());
            Assert.assertEquals(smartreviewSensorEventResponse.getStatusCode(), 200);
            // Multi Face event validation
            String responseString = responseArray.getJSONObject(0).toString();
            System.out.println(responseString);
            System.out.println(responseArray.length());
            Assert.assertEquals(responseArray.length(), 5);
            Assert.assertEquals(responseArray.getJSONObject(0).get("sensorEventLogType").toString(), "SENSOR_EVENT");
            Assert.assertEquals(responseArray.getJSONObject(0).get("autoProctorSensorID").toString(), useGlobalSensorId);
            Assert.assertEquals(responseArray.getJSONObject(0).get("onVueSessionID").toString(), "37621");
            Assert.assertEquals(responseArray.getJSONObject(0).get("registrationID").toString(), reservationAsString);
            Assert.assertEquals(responseArray.getJSONObject(0).get("sensorEventType").toString(), "MULTI_FACE");
            Assert.assertEquals(responseArray.getJSONObject(0).get("sensorEventStatus").toString(), "STARTED");
            Assert.assertEquals(responseArray.getJSONObject(1).get("sensorEventLogType").toString(), "SENSOR_EVENT");
            Assert.assertEquals(responseArray.getJSONObject(1).get("autoProctorSensorID").toString(), useGlobalSensorId);
            Assert.assertEquals(responseArray.getJSONObject(1).get("onVueSessionID").toString(), "37621");
            Assert.assertEquals(responseArray.getJSONObject(1).get("registrationID").toString(), reservationAsString);
            Assert.assertEquals(responseArray.getJSONObject(1).get("sensorEventType").toString(), "MULTI_FACE");
            Assert.assertEquals(responseArray.getJSONObject(1).get("sensorEventStatus").toString(), "STOPPED");

            // No Face Event validation
            Assert.assertEquals(responseArray.getJSONObject(2).get("sensorEventLogType").toString(), "SENSOR_EVENT");
            Assert.assertEquals(responseArray.getJSONObject(2).get("autoProctorSensorID").toString(), useGlobalSensorId);
            Assert.assertEquals(responseArray.getJSONObject(2).get("onVueSessionID").toString(), "37621");
            Assert.assertEquals(responseArray.getJSONObject(2).get("registrationID").toString(), reservationAsString);
            Assert.assertEquals(responseArray.getJSONObject(2).get("sensorEventType").toString(), "NO_FACE");
            Assert.assertEquals(responseArray.getJSONObject(2).get("sensorEventStatus").toString(), "STARTED");
            Assert.assertEquals(responseArray.getJSONObject(3).get("sensorEventLogType").toString(), "SENSOR_EVENT");
            Assert.assertEquals(responseArray.getJSONObject(3).get("autoProctorSensorID").toString(), useGlobalSensorId);
            Assert.assertEquals(responseArray.getJSONObject(3).get("onVueSessionID").toString(), "37621");
            Assert.assertEquals(responseArray.getJSONObject(3).get("registrationID").toString(), reservationAsString);
            Assert.assertEquals(responseArray.getJSONObject(3).get("sensorEventType").toString(), "NO_FACE");
            Assert.assertEquals(responseArray.getJSONObject(3).get("sensorEventStatus").toString(), "STOPPED");

            // Start event after Mute
            Assert.assertEquals(responseArray.getJSONObject(4).get("sensorEventStatus").toString(), "STARTED");
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }

    // post to notification endpoint with valid input and get response with status code 200
    @Test
    public void post_notification_validate_success_200() {
        try {
        String validSensorId = notificationPayload.Payload().replace(useGlobalSensorId, "sensorIdValue");
        notificationRequest = given().spec(requestSpecification).body(validSensorId);
        notificationResponse = notificationRequest.when().post(endpoint).
                then().extract().response();
        String responseString = notificationResponse.asString();
        System.out.println(responseString);
        Assert.assertEquals(notificationResponse.getStatusCode(), 200);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }


    // post to notification with invalid input
    @Test
    public void post_notification_bogus_endpoint_expect_not_found_404() {
        try {
        notificationRequest = given().spec(requestSpecification).body(startExamPayload.Payload());
        String path = "/rest/sensor/notification" + "bogus";
        notificationResponse = notificationRequest.when().post(path).
                then().extract().response();
        String responseString = notificationResponse.asString();
        System.out.println(path);
        System.out.println(responseString);
        Assert.assertEquals(notificationResponse.getStatusCode(), 404);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }

    // Launch Sensor Acknowledgement successful
    @Test (priority=4)
    public void launch_Sensor_acknowledgement_success_200() {
        try {
        sensorEventLaunchAck = given().spec(sensorEventLaunchAckRequest).body(launchAckPayload.Payload());
        sensorEventLaunchAckResponse = sensorEventLaunchAck.when().post("/rest/sensor/launchAck/").
                then().extract().response();
        String responseString1 = sensorEventLaunchAckResponse.asString();
        System.out.println(responseString1);
        Assert.assertEquals(sensorEventLaunchAckResponse.getStatusCode(), 200);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }

    // Shutdown Sensor Acknowledgement successful
    @Test (priority=11)
    public void shutdown_Sensor_acknowledgement_success_200() {
        try {
        sensorEventShutdownAck = given().spec(sensorEventShutdownAckRequest).body(launchAckPayload.Payload());
        sensorEventShutdownAckResponse = sensorEventShutdownAck.when().post("/rest/sensor/shutdownAck/").
                then().extract().response();
        String responseString = sensorEventShutdownAckResponse.asString();
        System.out.println(responseString);
        Assert.assertEquals(sensorEventShutdownAckResponse.getStatusCode(), 200);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }


    // end exam with valid input and get response with status code 200
    @Test(priority=12)
    public void endExam_Validation_with_Success_200() {
        try {
        endExamres1 = given().spec(endExamRequest).body(endExamPayload.Payload());
        endExamresponse = endExamres1.when().post("/rest/exam/end").
                then().extract().response();
        String responseString = endExamresponse.asString();
        System.out.println(responseString);
        Assert.assertEquals(endExamresponse.getStatusCode(), 200);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }

    //Error notification on front end sensor failed and back end sensor started for 102 error code , validate the error notification record in table.
    // Validate the Backend sensor launched successfully
    @Test(priority=13)
    public void errorNotification_backend_Sensor_Launch_102() {
        try {
            backendSensor_102_Request1 = given().spec(backendSensor_102_Request).body(errornotificationBackendPayload102.Payload());
            backendSensor_102_Response = backendSensor_102_Request1.when().post("/rest/sensor/notification").
                    then().extract().response();
            Assert.assertEquals(backendSensor_102_Response.getStatusCode(), 200);

            // Validate the sensor event table in smart review database for new error notification record with error code.
            reservationAsString = startExamPayload.reservation.toString();
            Thread.sleep(5000);
            smartreviewSensorEventResponse = given().contentType(ContentType.JSON).when().get(apsConfig.getsensorEventTableURL()+reservationAsString)
                    .then()
                    .extract()
                    .response();
            JSONArray responseArray = new JSONArray(smartreviewSensorEventResponse.asString());
            Assert.assertEquals(smartreviewSensorEventResponse.getStatusCode(), 200);
            String responseString = responseArray.getJSONObject(6).toString();
            System.out.println(responseString);
            System.out.println(responseArray.length());
            // There should be total 7 records in the table for no face event 3 ,  multi face event 2 , error code 101 and 102
            Assert.assertEquals(responseArray.length(), 7);
            Assert.assertEquals(responseArray.getJSONObject(6).get("sensorEventLogType").toString(), "SENSOR_NOTIFICATION");
            Assert.assertEquals(responseArray.getJSONObject(6).get("autoProctorSensorID").toString(), useGlobalSensorId);
            Assert.assertEquals(responseArray.getJSONObject(6).get("onVueSessionID").toString(), "37621");
            Assert.assertEquals(responseArray.getJSONObject(6).get("registrationID").toString(), reservationAsString);
            Assert.assertEquals(responseArray.getJSONObject(6).get("sensorEventType").toString(), "NOTIFICATION");
            Assert.assertEquals(responseArray.getJSONObject(6).get("sensorEventCode").toString(), "102");
            Assert.assertEquals(responseArray.getJSONObject(6).get("sensorEventLevel").toString(), "ERROR");

            Thread.sleep(5000);
            // Assert the back end sensor launched successfully
            sessionResponse = given().contentType(ContentType.JSON).when().get(apsConfig.getsessionTableURL()+reservationAsString)
                    .then()
                    .extract()
                    .response();
            String responseString1 = sessionResponse.asString();
            System.out.println(responseString1);
            Assert.assertEquals(sessionResponse.getStatusCode(), 200);
//            Assert.assertEquals(useGlobalSensorId, sessionResponse.jsonPath().getString("sessionSensorList[2].sensorID"));
//            Assert.assertEquals("BACKEND_FACE_SENSOR", sessionResponse.jsonPath().getString("sessionSensorList[2].sensorName"));
//            Assert.assertEquals("LAUNCH_SUCCESS", sessionResponse.jsonPath().getString("sessionSensorList[2].sensorStatus"));
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }

    //Error notification on front end sensor failed and back end sensor started for 101 error code, validate the error notification record in table.
    // Validate the Backend sensor launched successfully
    @Test(priority=13)
    public void errorNotification_backend_Sensor_Launch_101() {
        try {
            backendSensor_101_Request1 = given().spec(backendSensor_101_Request).body(errornotificationBackendPayload101.Payload());
            backendSensor_101_Response = backendSensor_101_Request1.when().post("/rest/sensor/notification").
                    then().extract().response();
            Assert.assertEquals(backendSensor_101_Response.getStatusCode(), 200);

            // Validate the sensor event table in smart review database for new error notification record with error code.
            reservationAsString = startExamPayload.reservation.toString();
            Thread.sleep(5000);
            smartreviewSensorEventResponse = given().contentType(ContentType.JSON).when().get(apsConfig.getsensorEventTableURL()+reservationAsString)
                    .then()
                    .extract()
                    .response();
            JSONArray responseArray = new JSONArray(smartreviewSensorEventResponse.asString());
            Assert.assertEquals(smartreviewSensorEventResponse.getStatusCode(), 200);
            String responseString = responseArray.getJSONObject(5).toString();
            System.out.println(responseString);
            System.out.println(responseArray.length());
            // There should be total 6 records in the table for no face event 3 ,  multi face event 2 , and error notification error code 101
            Assert.assertEquals(responseArray.length(), 6);
            Assert.assertEquals(responseArray.getJSONObject(5).get("sensorEventLogType").toString(), "SENSOR_NOTIFICATION");
            Assert.assertEquals(responseArray.getJSONObject(5).get("autoProctorSensorID").toString(), useGlobalSensorId);
            Assert.assertEquals(responseArray.getJSONObject(5).get("onVueSessionID").toString(), "37621");
            Assert.assertEquals(responseArray.getJSONObject(5).get("registrationID").toString(), reservationAsString);
            Assert.assertEquals(responseArray.getJSONObject(5).get("sensorEventType").toString(), "NOTIFICATION");
            Assert.assertEquals(responseArray.getJSONObject(5).get("sensorEventCode").toString(), "101");
            Assert.assertEquals(responseArray.getJSONObject(5).get("sensorEventLevel").toString(), "ERROR");
            Thread.sleep(5000);
            // Assert the back end sensor launched successfully
            sessionResponse = given().contentType(ContentType.JSON).when().get(apsConfig.getsessionTableURL()+reservationAsString)
                    .then()
                    .extract()
                    .response();
            String responseString1 = sessionResponse.asString();
            System.out.println(responseString1);
            Assert.assertEquals(sessionResponse.getStatusCode(), 200);
//            Assert.assertEquals(useGlobalSensorId, sessionResponse.jsonPath().getString("sessionSensorList[2].sensorID"));
//            Assert.assertEquals("BACKEND_FACE_SENSOR", sessionResponse.jsonPath().getString("sessionSensorList[2].sensorName"));
//            Assert.assertEquals("LAUNCH_SUCCESS", sessionResponse.jsonPath().getString("sessionSensorList[2].sensorStatus"));
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }


    // end exam with invalid URL and get response with status code 404
    @Test
    public void endExam_Validation_with_Failure_404() {
        try {
        endExamres1 = given().spec(endExamRequest).body(endExamPayload.Payload());
        endExamresponse = endExamres1.when().post("/rest/exam/end11").
                then().extract().response();
        String responseString = endExamresponse.asString();
        System.out.println(responseString);
        Assert.assertEquals(endExamresponse.getStatusCode(), 404);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }


    // launch sensor API with Invalid sensor id with status code 400
    @Test
    public void launch_Sensor_event_Invalid_success_400() {
        try {
        sensorEvent1 = given().spec(sensorEventRequest).body(invalidSensorIdPayload.Payload());
        sensorEventInvalidResponse = sensorEvent1.when().post("/rest/sensor/event/").
                then().extract().response();
        JSONArray responseString = new JSONArray(sensorEventInvalidResponse.asString());
        System.out.println(responseString);
        Assert.assertEquals(sensorEventInvalidResponse.getStatusCode(), 400);

        System.out.println(responseString.length());
        Assert.assertEquals(responseString.length(), 1);
        Assert.assertEquals(responseString.getJSONObject(0).get("code").toString(), "error.invalidSensorID");
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }

    // post to notification with invalid input
    @Test
    public void post_notification_invalid_attribute_expect_Bad_Request_400() {
        try {
        String invalidPayload = notificationPayload.Payload().replace("Id", "ID11");
        notificationRequest = given().spec(requestSpecification).body(invalidPayload);
        notificationResponse = notificationRequest.when().post("/rest/sensor/notification").
                then().extract().response();
        String responseString = notificationResponse.asString();
        System.out.println(responseString);
        Assert.assertEquals(notificationResponse.getStatusCode(), 400);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }

    // Get 204 response code message when session table record entry using Invalid reservation id and session id
    @Test
    public void sessionTableValidation_with_success_204() {
        try {
        sessionResponse = given().spec(startExamRequest).contentType(ContentType.JSON).when().get(apsConfig.getsessionTableURL()+"Automation2222")
                .then()
                .extract()
                .response();
        String responseString = sessionResponse.asString();
        System.out.println(responseString);
        Assert.assertEquals(sessionResponse.getStatusCode(), 204);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }

    //Negative test to validate 404 error code for start exam
    @Test
    public void startExam_Validation_with_Failure_404() {
        try {
        startExamres1 = given().spec(startExamRequest).body(startExamPayload.Payload());
        startExamresponse = startExamres1.when().post("/rest/exam/start111").
                then().extract().response();
        String responseString = startExamresponse.asString();
        System.out.println(responseString);
        Assert.assertEquals(startExamresponse.getStatusCode(), 404);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }

    //Verify valid client has not configured with face and item sensor for APS-automation client then, sensors should not launch.
    @Test
    public void client_configurationTest_APS_automation_noConfiguration() {
        try {
            blacklistClientRequest1 = given().spec(blacklistClientRequest).body(startExamWithNoClientcodeConfigured.Payload());
            blacklistClientResponse = blacklistClientRequest1.when().post("/rest/exam/start").
                    then().extract().response();
            String responseString = blacklistClientResponse.asString();
            System.out.println(responseString);
            reservationAsString1 = startExamWithNoClientcodeConfigured.reservation1.toString();
            System.out.println(reservationAsString1);
            Assert.assertEquals(blacklistClientResponse.getStatusCode(), 200);

            Thread.sleep(5000);
            // call reservation id from start exam Payload
            // User called reservation id to fetch the Get API
            sessionResponse1 = given().contentType(ContentType.JSON).when().get(apsConfig.getsessionTableURL()+reservationAsString1)
                    .then()
                    .extract()
                    .response();
            String responseString1 = sessionResponse1.asString();
            System.out.println(responseString1);
            // As there is no sensor launched for that reservation id , while trying to fetch the record using reservation id , we are getting 204 as no record found .
            Assert.assertEquals(sessionResponse1.getStatusCode(), 204);
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }
}
