package com.autoproctor.test.validation;

import com.autoproctor.test.config.APSConfig;
import com.autoproctor.test.files.endExamPayload;
import com.autoproctor.test.files.errornotificationBackendPayload101;
import com.autoproctor.test.files.errornotificationBackendPayload102;
import com.autoproctor.test.files.invalidSensorIdPayload;
import com.autoproctor.test.files.launchAckPayload;
import com.autoproctor.test.files.notificationPayload;
import com.autoproctor.test.files.sensorMultiFaceEventStartPayload;
import com.autoproctor.test.files.sensorMultiFaceEventStopPayload;
import com.autoproctor.test.files.sensorMutePayload;
import com.autoproctor.test.files.sensorNoFaceEventStartPayload;
import com.autoproctor.test.files.sensorNoFaceEventStopPayload;
import com.autoproctor.test.files.sensorPausePayload;
import com.autoproctor.test.files.sensorResumePayload;
import com.autoproctor.test.files.sensorUnMutePayload;
import com.autoproctor.test.files.startExamPayload;
import com.autoproctor.test.files.startExamWithNoClientcodeConfigured;
import com.autoproctor.test.service.APSService;
import com.autoproctor.test.service.CASService;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONArray;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.requestSpecification;

public class CASTest {
    private Response tokenResponse;
    private String token;

    APSConfig apsConfig;

    @BeforeTest
    public void setUp() {
        apsConfig = new APSConfig();
        // Set up token credentials
        token = CASService.getToken(apsConfig);
        tokenResponse = CASService.getTokenResponse(apsConfig);
        APSService apsService = new APSService(apsConfig,token);
    }

    //CAS Token access and assert
    @Test
    public void token_Validation_with_Success_200() {
        try {
            token = tokenResponse.jsonPath().get("access_token");
            Assert.assertEquals(tokenResponse.getStatusCode(), 200);
            System.out.println(tokenResponse.jsonPath().prettify());
        } catch (Exception e) {
            System.out.println ("Test failed " + e);
        }
    }

    //Negative test for CAS token
    @Test
    public void token_Validation_with_Failure_401() {
        try {
            //Unauthorized access - Invalid client secret
            Response resp = given()
                    //.formParam("client_id", apsConfig.getClientId())
                    .formParam("client_secret", apsConfig.getclientSecret())
                    .formParam("grant_type", apsConfig.getgrantType())
                    .post(apsConfig.getcasToken());
            //token = resp.jsonPath().get("access_token");
            Assert.assertEquals(resp.getStatusCode(), 401);
        } catch (Exception e) {
            System.out.println ("Token failed " + e);
        }
    }
}
