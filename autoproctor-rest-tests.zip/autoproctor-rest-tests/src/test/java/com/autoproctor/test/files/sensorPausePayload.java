package com.autoproctor.test.files;
public class sensorPausePayload {
    public static String Payload() {
        String reservationAsString;
        reservationAsString = startExamPayload.reservation.toString();
         return "{\n" +
                 "\"reservationId\":\"" + reservationAsString + "\",\n" +
                 "\"onVueSessionId\":37621,\n" +
                 "\"examSeriesCode\": \"2234517\",\n" +
                 "\"clientCode\": \"HEWPACK\",\n" +
                 "\"state\" :\"PAUSE\"\n" +
                 " \n" +
                 "}";
    }
}
