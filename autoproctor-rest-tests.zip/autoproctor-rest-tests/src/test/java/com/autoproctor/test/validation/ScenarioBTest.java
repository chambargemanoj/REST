package com.autoproctor.test.validation;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ScenarioBTest {

    @BeforeTest(groups = {"smoke"})
    public void setUp() {

    }

    @Test(priority=1, groups = {"smoke"})
    public void test_with_Success_200() {
        Assert.assertEquals(200, 200);
    }

    @Test(priority=1)
    public void test_no_smoke_with_Success_200() throws InterruptedException {
        Assert.assertEquals(200, 200);
    }
}
