package com.autoproctor.test.config;

import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import org.apache.http.conn.ssl.SSLSocketFactory;
import utility.PropertyConfigUtil;

import java.io.FileInputStream;
import java.security.KeyStore;

public class APSConfig {

    private String clientId;
    private String clientSecret;
    private String grantType;
    private String casToken;
    private String baseUrl;
    private String certurl;
    private String envpassword;
    private String sessionTableURL;
    private String sensorEventTableURL;

    public APSConfig() {
        init();
    }

    public void init(){
        //Property file
        final PropertyConfigUtil propertyConfigUtil = new PropertyConfigUtil();
        propertyConfigUtil.loadPropertyFile("configs/environment.properties");
        clientId = propertyConfigUtil.getPropertyValue("clientId");
        clientSecret = propertyConfigUtil.getPropertyValue("clientSecret");
        grantType = propertyConfigUtil.getPropertyValue("grantType");
        casToken = propertyConfigUtil.getPropertyValue("casToken");
        baseUrl = propertyConfigUtil.getPropertyValue("ap-base-url");
        certurl = propertyConfigUtil.getPropertyValue("certurl");
        envpassword = propertyConfigUtil.getPropertyValue("envpassword");
        sessionTableURL = propertyConfigUtil.getPropertyValue("sessionTableURL");
        sensorEventTableURL = propertyConfigUtil.getPropertyValue("sensorEventTableURL");

        try {
            // Load the KeyStore
            KeyStore keyStore = KeyStore.getInstance("PKCS12");
            keyStore.load(new FileInputStream(this.getCerturl()), this.getEnvpassword().toCharArray());
            // Configure SSL settings
            final SSLSocketFactory clientAuthFactory = new SSLSocketFactory(keyStore, this.getEnvpassword());
            SSLConfig config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

            // Set SSL config into Rest Assured settings
            RestAssured.config = RestAssured.config().sslConfig(config);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public String getClientId() {
        return clientId;
    }

    public String getclientSecret() {
        return clientSecret;
    }

    public String getgrantType() {
        return grantType;
    }

    public String getcasToken() {
        return casToken;
    }

    public String getbaseUrl() {
        return baseUrl;
    }

    public String getCerturl() {
        return certurl;
    }

    public String getEnvpassword() {
        return envpassword;
    }

    public String getsessionTableURL() {
        return sessionTableURL;
    }

    public String getsensorEventTableURL() { return sensorEventTableURL; }


}
