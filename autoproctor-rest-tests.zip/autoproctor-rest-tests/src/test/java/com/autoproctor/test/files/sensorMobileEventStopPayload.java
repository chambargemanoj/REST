package com.autoproctor.test.files;

import com.autoproctor.test.validation.StartAndEndExamTest;

public class sensorMobileEventStopPayload {


    public static  String  Payload () {
        String sensorIDCopy;
        sensorIDCopy = StartAndEndExamTest.useItemSensorId;
        return "{\n" +
                "    \"sensorId\": \""+sensorIDCopy+"\",\n" +
                "    \"eventTime\": 160795509000,\n" +
                "    \"eventType\": \"MOBILE\",\n" +
                "    \"status\": \"STOPPED\",\n" +
                "    \"confidence\": 0.72,\n" +
                "    \"eventData\": [\n" +
                "        {\n" +
                "            \"id\": \"SampExamId\",\n" +
                "            \"value\": \"SampTEST123\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"id\": \"Candidate_Name\",\n" +
                "            \"value\": \"Sampxyz123\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
    }
}
