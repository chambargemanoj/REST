package com.autoproctor.test.files;

public class invalidSensorIdPayload {
    public static  String  Payload () {
        return "{\n" +
                "    \"sensorId\": \"09502b94-1612-4af8-b3f2-9a71e8b49d471111111111111\",\n" +
                "    \"eventTime\": 160795507000,\n" +
                "    \"eventType\": \"NO_FACE\",\n" +
                "    \"status\": \"STOPPED\",\n" +
                "    \"confidence\": 0.72,\n" +
                "    \"eventData\": [\n" +
                "        {\n" +
                "            \"id\": \"SampExamId\",\n" +
                "            \"value\": \"SampTEST123\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"id\": \"Candidate_Name\",\n" +
                "            \"value\": \"Sampxyz123\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
    }
}
