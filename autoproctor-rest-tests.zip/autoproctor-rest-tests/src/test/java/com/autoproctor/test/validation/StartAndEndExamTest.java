package com.autoproctor.test.validation;

import com.autoproctor.test.files.*;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.json.JSONArray;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import utility.PropertyConfigUtil;

import java.io.FileInputStream;
import java.security.KeyStore;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.oauth2;

public class StartAndEndExamTest {
    String token;
    RequestSpecification getAccessToken;
    Response tokenResponse;
    private String clientId;
    private String clientSecret;
    private String grantType;
    private String casToken;
    private String baseUrl;
    private String certurl;
    private String envpassword;
    private String sessionTableURL;
    private String sensorEventTableURL;

    public String getClientId() {
        return clientId;
    }

    public String getclientSecret() {
        return clientSecret;
    }

    public String getgrantType() {
        return grantType;
    }

    public String getcasToken() {
        return casToken;
    }

    public String getbaseUrl() {
        return baseUrl;
    }

    public String getCerturl() {
        return certurl;
    }

    public String getEnvpassword() {
        return envpassword;
    }

    public String getsessionTableURL() {
        return sessionTableURL;
    }

    public String getsensorEventTableURL() {
        return sensorEventTableURL;
    }

    public static String useGlobalSensorId;
    public static String useItemSensorId;
    public static String reservationAsString;
    public static String reservationAsString1;


    @BeforeTest(groups = {"smoke"})
    public void setUp() {
        //Property file
        final PropertyConfigUtil propertyConfigUtil = new PropertyConfigUtil();
        propertyConfigUtil.loadPropertyFile("configs/environment.properties");
        clientId = propertyConfigUtil.getPropertyValue("clientId");
        clientSecret = propertyConfigUtil.getPropertyValue("clientSecret");
        grantType = propertyConfigUtil.getPropertyValue("grantType");
        casToken = propertyConfigUtil.getPropertyValue("casToken");
        baseUrl = propertyConfigUtil.getPropertyValue("ap-base-url");
        certurl = propertyConfigUtil.getPropertyValue("certurl");
        envpassword = propertyConfigUtil.getPropertyValue("envpassword");
        sessionTableURL = propertyConfigUtil.getPropertyValue("sessionTableURL");
        sensorEventTableURL = propertyConfigUtil.getPropertyValue("sensorEventTableURL");

        try {
            // Load the KeyStore
            KeyStore keyStore = KeyStore.getInstance("PKCS12");
            keyStore.load(new FileInputStream(this.getCerturl()), this.getEnvpassword().toCharArray());
            // Configure SSL settings
            final SSLSocketFactory clientAuthFactory = new SSLSocketFactory(keyStore, this.getEnvpassword());
            SSLConfig config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

            // Set SSL config into Rest Assured settings
            RestAssured.config = RestAssured.config().sslConfig(config);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Set up token credentials
        tokenResponse = given()
                .formParam("client_id", getClientId())
                .formParam("client_secret", getclientSecret())
                .formParam("grant_type", getgrantType())
                .formParam("certurl", getCerturl())
                .formParam("envpassword", getEnvpassword())
                .formParam("sessionTableURL", getsessionTableURL())
                .formParam("sensorEventTableURL", getsensorEventTableURL())
                .post(getcasToken());
        token = tokenResponse.jsonPath().get("access_token");
        Assert.assertEquals(tokenResponse.getStatusCode(), 200);
        System.out.println(tokenResponse.jsonPath().prettify());

        // set up to get CAS token - Access token
        getAccessToken = new RequestSpecBuilder().setBaseUri(getbaseUrl())
                .setAuth(oauth2(token)).setContentType("application/json").build();

    }

    //CAS Token access and assert
    @Test (groups = {"smoke"})
    public void token_Validation_with_Success_200() {
        try {
            token = tokenResponse.jsonPath().get("access_token");
            Assert.assertEquals(tokenResponse.getStatusCode(), 200);
            System.out.println(tokenResponse.jsonPath().prettify());
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    //Start the exam with valid payload request
    @Test(priority = 1, groups = {"smoke"})
    public void startExam_Validation_with_Success_200() throws InterruptedException {
        try {
            RequestSpecification startExamResBody = given().spec(getAccessToken).body(startExamPayload.Payload());
            Response startExamResponse = startExamResBody.when().post("/rest/exam/start").
                    then().extract().response();
            String responseString = startExamResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(startExamResponse.getStatusCode(), 200);
            Thread.sleep(5000);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    // Get the session table record entry using valid reservation id and session id
    @Test(priority = 2, groups = {"smoke"})
    public void sessionTableValidation_with_Success_200() {
        try {
            Thread.sleep(20000);
            // call reservation id from start exam Payload
            reservationAsString = startExamPayload.reservation.toString();
            // User called reservation id to fetch the Get API
            Response sessionResponse = given().spec(getAccessToken).contentType(ContentType.JSON).when().get(sessionTableURL + reservationAsString)
                    .then()
                    .extract()
                    .response();
            String responseString = sessionResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sessionResponse.getStatusCode(), 200);
            Assert.assertEquals(reservationAsString, sessionResponse.jsonPath().getString("reservationId"));
            Assert.assertEquals("37621", sessionResponse.jsonPath().getString("onVueSessionId"));
            Assert.assertEquals("HEWPACK", sessionResponse.jsonPath().getString("clientCode"));
            Assert.assertEquals("2234517", sessionResponse.jsonPath().getString("examSeriesCode"));
            Assert.assertEquals("SampleID", sessionResponse.jsonPath().getString("clientCandidateId"));
            Assert.assertEquals("USA", sessionResponse.jsonPath().getString("demographicsCountry"));
            Assert.assertEquals("MN", sessionResponse.jsonPath().getString("demographicsState"));
            Assert.assertEquals("ONVUEC;ONVUEH", sessionResponse.jsonPath().getString("accommodations"));
            Assert.assertEquals("9aea40ce_stream1", sessionResponse.jsonPath().getString("webRtcStreamName"));
            Assert.assertEquals("app-b43X3PBH", sessionResponse.jsonPath().getString("webRtcApplicationName"));
            Assert.assertEquals("FACE_SENSOR", sessionResponse.jsonPath().getString("sessionSensorList[0].sensorName"));
            Assert.assertEquals("LAUNCH_FAIL", sessionResponse.jsonPath().getString("sessionSensorList[0].sensorStatus"));
            Assert.assertEquals("ITEM_SENSOR", sessionResponse.jsonPath().getString("sessionSensorList[1].sensorName"));
            Assert.assertEquals("LAUNCH_FAIL", sessionResponse.jsonPath().getString("sessionSensorList[1].sensorStatus"));
            useGlobalSensorId = sessionResponse.jsonPath().getString("sessionSensorList[0].sensorID");
            useItemSensorId = sessionResponse.jsonPath().getString("sessionSensorList[1].sensorID");
            System.out.println(useGlobalSensorId);
            System.out.println(useItemSensorId);
            System.out.println(reservationAsString);
        } catch (AssertionError | InterruptedException e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    // Get the session_sensor table record entry using valid reservation id and session id
    @Test(priority = 3)
    public void sessionSensor_TableValidation_with_Success_200() {
        try {
            reservationAsString = startExamPayload.reservation.toString();
            Response sessionResponse = given().spec(getAccessToken).contentType(ContentType.JSON).when().get(sessionTableURL + reservationAsString)
                    .then()
                    .extract()
                    .response();
            String responseString = sessionResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sessionResponse.getStatusCode(), 200);
            Assert.assertEquals(useGlobalSensorId, sessionResponse.jsonPath().getString("sessionSensorList[0].sensorID"));
            Assert.assertEquals("FACE_SENSOR", sessionResponse.jsonPath().getString("sessionSensorList[0].sensorName"));
            Assert.assertEquals("LAUNCH_FAIL", sessionResponse.jsonPath().getString("sessionSensorList[0].sensorStatus"));
            Assert.assertEquals(useItemSensorId, sessionResponse.jsonPath().getString("sessionSensorList[1].sensorID"));
            Assert.assertEquals("ITEM_SENSOR", sessionResponse.jsonPath().getString("sessionSensorList[1].sensorName"));
            Assert.assertEquals("LAUNCH_FAIL", sessionResponse.jsonPath().getString("sessionSensorList[1].sensorStatus"));
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }


    // Start event with launch sensor API with valid sensor id with status code 200 - No Face Event
    @Test(priority = 3)
    public void launch_Sensor_noFace_event_Start_success_200() {
        try {
            RequestSpecification sensorEventBody = given().spec(getAccessToken).body(sensorNoFaceEventStartPayload.Payload());
            Response sensorEventResponse = sensorEventBody.when().post("/rest/sensor/event/").
                    then().extract().response();
            String responseString = sensorEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorEventResponse.getStatusCode(), 200);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    // Stop event with launch sensor API with valid sensor id with status code 200   - No Face Event
    @Test(priority = 3)
    public void launch_Sensor_noFace_event_Stop_success_200() {
        try {
            RequestSpecification sensorEventBody = given().spec(getAccessToken).body(sensorNoFaceEventStopPayload.Payload());
            Response sensorEventResponse = sensorEventBody.when().post("/rest/sensor/event/").
                    then().extract().response();
            String responseString = sensorEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorEventResponse.getStatusCode(), 200);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    // Item sensor event Mobile START event using item sensor - Mobile Event
    @Test(priority = 3)
    public void launch_itemSensor_Mobile_event_Start_success_200() {
        try {
            RequestSpecification itemSensorEventBody = given().spec(getAccessToken).body(sensorMobileEventStartPayload.Payload());
            Response itemSensorEventResponse = itemSensorEventBody.when().post("/rest/sensor/event/").
                    then().extract().response();
            String responseString = itemSensorEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(itemSensorEventResponse.getStatusCode(), 200);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    //   Item sensor event Mobile STOP event using item sensor  - Mobile Event
    @Test(priority = 3)
    public void launch_itemSensor_Mobile_event_stopped_success_200() {
        try {
            RequestSpecification itemSensorEventBody = given().spec(getAccessToken).body(sensorMobileEventStopPayload.Payload());
            Response itemSensorEventResponse = itemSensorEventBody.when().post("/rest/sensor/event/").
                    then().extract().response();
            String responseString = itemSensorEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(itemSensorEventResponse.getStatusCode(), 200);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    // Pause sensor test scenario when the sensor launches
    @Test(priority = 4)
    public void pause_Sensor_event_success_200() {
        try {
            RequestSpecification sensorPauseEventRequestBody = given().spec(getAccessToken).body(sensorPausePayload.Payload());
            Response sensorPauseEventResponse = sensorPauseEventRequestBody.when().post("/rest/exam/pausesensor").
                    then().extract().response();
            String responseString = sensorPauseEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorPauseEventResponse.getStatusCode(), 200);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    // Start event when the Sensor Paused - It should not create the event
    @Test(priority = 5)
    public void launch_Sensor_noFace_event_Start() {
        try {
            RequestSpecification sensorEventBody = given().spec(getAccessToken).body(sensorNoFaceEventStartPayload.Payload());
            Response sensorEventResponse = sensorEventBody.when().post("/rest/sensor/event/").
                    then().extract().response();
            String responseString = sensorEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorEventResponse.getStatusCode(), 200);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    //    // Resume sensor test scenario when the sensor paused
    @Test(priority = 6)
    public void resume_Sensor_event_success_200() {
        try {
            RequestSpecification sensorResumeEventRequestBody = given().spec(getAccessToken).body(sensorResumePayload.Payload());
            Response sensorResumeEventResponse = sensorResumeEventRequestBody.when().post("/rest/exam/pausesensor").
                    then().extract().response();
            String responseString = sensorResumeEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorResumeEventResponse.getStatusCode(), 200);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    // Mute sensor test scenario when the sensor launches
    @Test(priority = 7)
    public void mute_Sensor_event_success_200() {
        try {
            RequestSpecification sensorMuteEventRequestBody = given().spec(getAccessToken).body(sensorMutePayload.Payload());
            Response sensorMuteEventResponse = sensorMuteEventRequestBody.when().post("/rest/exam/mutesensor/").
                    then().extract().response();
            String responseString = sensorMuteEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorMuteEventResponse.getStatusCode(), 200);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    // Start event when the Sensor Paused - It should not create the event
    @Test(priority = 8)
    public void launch_Sensor_NoFace_Mute_event_Start() {
        try {
            RequestSpecification sensorEventBody = given().spec(getAccessToken).body(sensorNoFaceEventStartPayload.Payload());
            Response sensorEventResponse = sensorEventBody.when().post("/rest/sensor/event/").
                    then().extract().response();
            String responseString = sensorEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorEventResponse.getStatusCode(), 200);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    //    // unMute sensor test scenario when the sensor Muted
    @Test(priority = 9)
    public void unMute_Sensor_event_success_200() {
        try {
            RequestSpecification sensorUnMuteEventRequestBody = given().spec(getAccessToken).body(sensorUnMutePayload.Payload());
            Response sensorUnMuteEventResponse = sensorUnMuteEventRequestBody.when().post("/rest/exam/mutesensor/").
                    then().extract().response();
            String responseString = sensorUnMuteEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorUnMuteEventResponse.getStatusCode(), 200);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }


    // Start event with launch sensor API with valid sensor id with status code 200 - Multi Face Event
    @Test(priority = 3)
    public void launch_Sensor_multiFace_event_Start_success_200() {
        try {
            RequestSpecification sensorEventBody = given().spec(getAccessToken).body(sensorMultiFaceEventStartPayload.Payload());
            Response sensorEventResponse = sensorEventBody.when().post("/rest/sensor/event/").
                    then().extract().response();
            String responseString = sensorEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorEventResponse.getStatusCode(), 200);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }


    // Stop event with launch sensor API with valid sensor id with status code 200   - Multi Face Event Event
    @Test(priority = 3)
    public void launch_Sensor_multiFace_event_Stop_success_200() {
        try {
            RequestSpecification sensorEventBody = given().spec(getAccessToken).body(sensorMultiFaceEventStopPayload.Payload());
            Response sensorEventResponse = sensorEventBody.when().post("/rest/sensor/event/").
                    then().extract().response();
            String responseString = sensorEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorEventResponse.getStatusCode(), 200);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    // Get the sensor_event_log table record entry from SmartReview database using valid reservation id and session id
    @Test(priority = 10)
    public void smartReviewDB_senserEvent_log_TableValidation_with_Success_200() {
        try {
            reservationAsString = startExamPayload.reservation.toString();
            Thread.sleep(10000);
            Response smartReviewSensorEventResponse = given().spec(getAccessToken).contentType(ContentType.JSON).when().get(sensorEventTableURL + reservationAsString)
                    .then()
                    .extract()
                    .response();
            JSONArray responseArray = new JSONArray(smartReviewSensorEventResponse.asString());
            Assert.assertEquals(smartReviewSensorEventResponse.getStatusCode(), 200);
            // Multi Face event validation
            String responseString = responseArray.getJSONObject(0).toString();
            System.out.println(responseString);
            System.out.println(responseArray.length());
            Assert.assertEquals(responseArray.length(), 7);
            Assert.assertEquals(responseArray.getJSONObject(0).get("sensorEventLogType").toString(), "SENSOR_EVENT");
            Assert.assertEquals(responseArray.getJSONObject(0).get("autoProctorSensorID").toString(), useGlobalSensorId);
            Assert.assertEquals(responseArray.getJSONObject(0).get("onVueSessionID").toString(), "37621");
            Assert.assertEquals(responseArray.getJSONObject(0).get("registrationID").toString(), reservationAsString);
            Assert.assertEquals(responseArray.getJSONObject(0).get("sensorEventType").toString(), "MULTI_FACE");
            Assert.assertEquals(responseArray.getJSONObject(0).get("sensorEventStatus").toString(), "STARTED");
            Assert.assertEquals(responseArray.getJSONObject(1).get("sensorEventLogType").toString(), "SENSOR_EVENT");
            Assert.assertEquals(responseArray.getJSONObject(1).get("autoProctorSensorID").toString(), useGlobalSensorId);
            Assert.assertEquals(responseArray.getJSONObject(1).get("onVueSessionID").toString(), "37621");
            Assert.assertEquals(responseArray.getJSONObject(1).get("registrationID").toString(), reservationAsString);
            Assert.assertEquals(responseArray.getJSONObject(1).get("sensorEventType").toString(), "MULTI_FACE");
            Assert.assertEquals(responseArray.getJSONObject(1).get("sensorEventStatus").toString(), "STOPPED");

            // No Face Event validation
            Assert.assertEquals(responseArray.getJSONObject(2).get("sensorEventLogType").toString(), "SENSOR_EVENT");
            Assert.assertEquals(responseArray.getJSONObject(2).get("autoProctorSensorID").toString(), useGlobalSensorId);
            Assert.assertEquals(responseArray.getJSONObject(2).get("onVueSessionID").toString(), "37621");
            Assert.assertEquals(responseArray.getJSONObject(2).get("registrationID").toString(), reservationAsString);
            Assert.assertEquals(responseArray.getJSONObject(2).get("sensorEventType").toString(), "NO_FACE");
            Assert.assertEquals(responseArray.getJSONObject(2).get("sensorEventStatus").toString(), "STARTED");
            Assert.assertEquals(responseArray.getJSONObject(3).get("sensorEventLogType").toString(), "SENSOR_EVENT");
            Assert.assertEquals(responseArray.getJSONObject(3).get("autoProctorSensorID").toString(), useGlobalSensorId);
            Assert.assertEquals(responseArray.getJSONObject(3).get("onVueSessionID").toString(), "37621");
            Assert.assertEquals(responseArray.getJSONObject(3).get("registrationID").toString(), reservationAsString);
            Assert.assertEquals(responseArray.getJSONObject(3).get("sensorEventType").toString(), "NO_FACE");
            Assert.assertEquals(responseArray.getJSONObject(3).get("sensorEventStatus").toString(), "STOPPED");

            // Item Sensor Event validation
            Assert.assertEquals(responseArray.getJSONObject(4).get("sensorEventLogType").toString(), "SENSOR_EVENT");
            Assert.assertEquals(responseArray.getJSONObject(4).get("autoProctorSensorID").toString(), useItemSensorId);
            Assert.assertEquals(responseArray.getJSONObject(4).get("onVueSessionID").toString(), "37621");
            Assert.assertEquals(responseArray.getJSONObject(4).get("registrationID").toString(), reservationAsString);
            Assert.assertEquals(responseArray.getJSONObject(4).get("sensorEventType").toString(), "MOBILE");
            Assert.assertEquals(responseArray.getJSONObject(4).get("sensorEventStatus").toString(), "STARTED");
            Assert.assertEquals(responseArray.getJSONObject(5).get("sensorEventLogType").toString(), "SENSOR_EVENT");
            Assert.assertEquals(responseArray.getJSONObject(5).get("autoProctorSensorID").toString(), useItemSensorId);
            Assert.assertEquals(responseArray.getJSONObject(5).get("onVueSessionID").toString(), "37621");
            Assert.assertEquals(responseArray.getJSONObject(5).get("registrationID").toString(), reservationAsString);
            Assert.assertEquals(responseArray.getJSONObject(5).get("sensorEventType").toString(), "MOBILE");
            Assert.assertEquals(responseArray.getJSONObject(5).get("sensorEventStatus").toString(), "STOPPED");
            // Start event after Mute
            Assert.assertEquals(responseArray.getJSONObject(4).get("sensorEventStatus").toString(), "STARTED");
        } catch (AssertionError | InterruptedException e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    // post to notification endpoint with valid input and get response with status code 200
    @Test (priority = 11)
    public void post_notification_validate_success_200() {
        try {
//            String validSensorId = notificationPayload.Payload().replace(useGlobalSensorId, "sensorIdValue");
            RequestSpecification notificationRequestOPBody = given().spec(getAccessToken).body(notificationPayload.Payload());
            Response notificationRequestOPResponse = notificationRequestOPBody.when().post("/rest/sensor/notification").
                    then().extract().response();
            Assert.assertEquals(notificationRequestOPResponse.getStatusCode(), 200);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }


    // post to notification with invalid input
    @Test
    public void post_notification_bogus_endpoint_expect_not_found_404() {
        try {
            RequestSpecification notificationRequest = given().spec(getAccessToken).body(startExamPayload.Payload());
            String path = "/rest/sensor/notification" + "bogus";
            Response notificationResponse = notificationRequest.when().post(path).
                    then().extract().response();
            String responseString = notificationResponse.asString();
            System.out.println(path);
            System.out.println(responseString);
            Assert.assertEquals(notificationResponse.getStatusCode(), 404);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    // Launch Sensor Acknowledgement successful
    @Test(priority = 4)
    public void launch_Sensor_acknowledgement_success_200() {
        try {
            RequestSpecification sensorEventLaunchAck = given().spec(getAccessToken).body(launchAckPayload.Payload());
            Response sensorEventLaunchAckResponse = sensorEventLaunchAck.when().post("/rest/sensor/launchAck/").
                    then().extract().response();
            String responseString1 = sensorEventLaunchAckResponse.asString();
            System.out.println(responseString1);
            Assert.assertEquals(sensorEventLaunchAckResponse.getStatusCode(), 200);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    // Shutdown Sensor Acknowledgement successful
    @Test(priority = 11)
    public void shutdown_Sensor_acknowledgement_success_200() {
        try {
            RequestSpecification sensorEventShutdownAckBody = given().spec(getAccessToken).body(launchAckPayload.Payload());
            Response sensorEventShutdownAckResponse = sensorEventShutdownAckBody.when().post("/rest/sensor/shutdownAck/").
                    then().extract().response();
            String responseString = sensorEventShutdownAckResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorEventShutdownAckResponse.getStatusCode(), 200);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }


    // end exam with valid input and get response with status code 200
    @Test(priority = 15, groups = {"smoke"})
    public void endExam_Validation_with_Success_200() {
        try {
            RequestSpecification endExamResBody = given().spec(getAccessToken).body(endExamPayload.Payload());
            Response endExamResponse = endExamResBody.when().post("/rest/exam/end").
                    then().extract().response();
            String responseString = endExamResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(endExamResponse.getStatusCode(), 200);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    //Error notification on front end sensor failed and back end sensor started for 102 error code , validate the error notification record in table.
    // Validate the Backend sensor launched successfully
    @Test(priority = 13)
    public void errorNotification_backend_Sensor_Launch_102() {
        try {
            RequestSpecification backendSensor_102_RequestBody = given().spec(getAccessToken).body(errornotificationBackendPayload102.Payload());
            Response backendSensor_102_Response = backendSensor_102_RequestBody.when().post("/rest/sensor/notification").
                    then().extract().response();
            Assert.assertEquals(backendSensor_102_Response.getStatusCode(), 200);

            // Validate the sensor event table in smart review database for new error notification record with error code.
            reservationAsString = startExamPayload.reservation.toString();
            Thread.sleep(10000);
            Response smartReviewSensorEventResponse = given().spec(getAccessToken).contentType(ContentType.JSON).when().get(sensorEventTableURL + reservationAsString)
                    .then()
                    .extract()
                    .response();
            JSONArray responseArray = new JSONArray(smartReviewSensorEventResponse.asString());
            Assert.assertEquals(smartReviewSensorEventResponse.getStatusCode(), 200);
            String responseString = responseArray.getJSONObject(6).toString();
            System.out.println(responseString);
            System.out.println(responseArray.length());
            // There should be total 7 records in the table for no face event 3 ,  multi face event 2 , error code 101 and 102
            Assert.assertEquals(responseArray.length(), 10);
            Assert.assertEquals(responseArray.getJSONObject(9).get("sensorEventLogType").toString(), "SENSOR_NOTIFICATION");
            Assert.assertEquals(responseArray.getJSONObject(9).get("autoProctorSensorID").toString(), useGlobalSensorId);
            Assert.assertEquals(responseArray.getJSONObject(9).get("onVueSessionID").toString(), "37621");
            Assert.assertEquals(responseArray.getJSONObject(9).get("registrationID").toString(), reservationAsString);
            Assert.assertEquals(responseArray.getJSONObject(9).get("sensorEventType").toString(), "NOTIFICATION");
            Assert.assertEquals(responseArray.getJSONObject(9).get("sensorEventCode").toString(), "102");
            Assert.assertEquals(responseArray.getJSONObject(9).get("sensorEventLevel").toString(), "ERROR");

            Thread.sleep(5000);
            // Assert the back end sensor launched successfully
            Response sessionResponse = given().spec(getAccessToken).contentType(ContentType.JSON).when().get(sessionTableURL + reservationAsString)
                    .then()
                    .extract()
                    .response();
            String responseString1 = sessionResponse.asString();
            System.out.println(responseString1);
            Assert.assertEquals(sessionResponse.getStatusCode(), 200);
            Assert.assertEquals("BACKEND_FACE_SENSOR", sessionResponse.jsonPath().getString("sessionSensorList[2].sensorName"));
            Assert.assertEquals("LAUNCH_SUCCESS", sessionResponse.jsonPath().getString("sessionSensorList[2].sensorStatus"));
        } catch (AssertionError | InterruptedException e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    //Error notification on front end sensor failed and back end sensor started for 101 error code, validate the error notification record in table.
    // Validate the Backend sensor launched successfully
    @Test(priority = 14)
    public void errorNotification_backend_Sensor_Launch_101() {
        try {
            RequestSpecification backendSensor_101_Request1 = given().spec(getAccessToken).body(errornotificationBackendPayload101.Payload());
            Response backendSensor_101_Response = backendSensor_101_Request1.when().post("/rest/sensor/notification").
                    then().extract().response();
            Assert.assertEquals(backendSensor_101_Response.getStatusCode(), 200);

            // Validate the sensor event table in smart review database for new error notification record with error code.
            reservationAsString = startExamPayload.reservation.toString();
            Thread.sleep(10000);
            Response smartReviewSensorEventResponse = given().spec(getAccessToken).contentType(ContentType.JSON).when().get(sensorEventTableURL + reservationAsString)
                    .then()
                    .extract()
                    .response();
            JSONArray responseArray = new JSONArray(smartReviewSensorEventResponse.asString());
            Assert.assertEquals(smartReviewSensorEventResponse.getStatusCode(), 200);
            String responseString = responseArray.getJSONObject(5).toString();
            System.out.println(responseString);
            System.out.println(responseArray.length());
            // There should be total 6 records in the table for no face event 3 ,  multi face event 2 , and error notification error code 101
            Assert.assertEquals(responseArray.length(), 11);
            Assert.assertEquals(responseArray.getJSONObject(10).get("sensorEventLogType").toString(), "SENSOR_NOTIFICATION");
            Assert.assertEquals(responseArray.getJSONObject(10).get("autoProctorSensorID").toString(), useGlobalSensorId);
            Assert.assertEquals(responseArray.getJSONObject(10).get("onVueSessionID").toString(), "37621");
            Assert.assertEquals(responseArray.getJSONObject(10).get("registrationID").toString(), reservationAsString);
            Assert.assertEquals(responseArray.getJSONObject(10).get("sensorEventType").toString(), "NOTIFICATION");
            Assert.assertEquals(responseArray.getJSONObject(10).get("sensorEventCode").toString(), "101");
            Assert.assertEquals(responseArray.getJSONObject(10).get("sensorEventLevel").toString(), "ERROR");
            Thread.sleep(10000);
            // Assert the back end sensor launched successfully
            Response sessionResponse = given().spec(getAccessToken).contentType(ContentType.JSON).when().get(sessionTableURL + reservationAsString)
                    .then()
                    .extract()
                    .response();
            String responseString1 = sessionResponse.asString();
            System.out.println(responseString1);
            Assert.assertEquals(sessionResponse.getStatusCode(), 200);
            Assert.assertEquals("BACKEND_FACE_SENSOR", sessionResponse.jsonPath().getString("sessionSensorList[2].sensorName"));
            Assert.assertEquals("LAUNCH_SUCCESS", sessionResponse.jsonPath().getString("sessionSensorList[2].sensorStatus"));
        } catch (AssertionError | InterruptedException e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }


    // When the event started and exam aborted and back end sensor started  then the start event has successfully stopped and both start and stop event came in table.
    // When the event started and exam Paused then the start event has successfully stopped and both start and stop event came in table.
    // User story B-109733
    @Test(priority = 14)
    public void stopEventSuccess_eXamAbort_eXamPause() {
        try {
            // Create start event for abort sensor and expect stop event in the table with additional record.
            RequestSpecification sensorEventBody = given().spec(getAccessToken).body(sensorMultiFaceEventStartPayload.Payload());
            Response sensorEventResponse = sensorEventBody.when().post("/rest/sensor/event/").
                    then().extract().response();
            String responseString = sensorEventResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sensorEventResponse.getStatusCode(), 200);
            Thread.sleep(10000);
            // Abort the front end sensor and launch back end.
            RequestSpecification backendSensor_102_RequestBody = given().spec(getAccessToken).body(errornotificationBackendPayload102.Payload());
            Response backendSensor_102_Response = backendSensor_102_RequestBody.when().post("/rest/sensor/notification").
                    then().extract().response();
            Assert.assertEquals(backendSensor_102_Response.getStatusCode(), 200);

            // Create start event for Pause sensor and expect stop event in the table with additional record.
            sensorEventBody = given().spec(getAccessToken).body(sensorMultiFaceEventStartPayload.Payload());
            sensorEventResponse = sensorEventBody.when().post("/rest/sensor/event/").
                    then().extract().response();
            Assert.assertEquals(sensorEventResponse.getStatusCode(), 200);
            Thread.sleep(10000);

            // Pause the sensor and expect the started event will stop and stop record entry came in data base table.
            RequestSpecification sensorPauseEventRequestBody = given().spec(getAccessToken).body(sensorPausePayload.Payload());
            Response sensorPauseEventResponse = sensorPauseEventRequestBody.when().post("/rest/exam/pausesensor").
                    then().extract().response();
            Assert.assertEquals(sensorPauseEventResponse.getStatusCode(), 200);

            // Validate the sensor event table in smart review database for new error notification record with error code.
            reservationAsString = startExamPayload.reservation.toString();
            Thread.sleep(5000);
            Response smartReviewSensorEventResponse = given().spec(getAccessToken).contentType(ContentType.JSON).when().get(sensorEventTableURL + reservationAsString)
                    .then()
                    .extract()
                    .response();
            JSONArray responseArray = new JSONArray(smartReviewSensorEventResponse.asString());
            Assert.assertEquals(smartReviewSensorEventResponse.getStatusCode(), 200);
            String responseString2 = responseArray.getJSONObject(8).toString();
            System.out.println(responseString2);
            System.out.println(responseArray.length());
            // There should be total 13 records in the table for no face event 4 ,  multi face event 6 , and error notification error code 3
            Assert.assertEquals(responseArray.length(), 16);
            // Stop Event generated even when sensor aborted
            Assert.assertEquals(responseArray.getJSONObject(12).get("sensorEventLogType").toString(), "SENSOR_EVENT");
            Assert.assertEquals(responseArray.getJSONObject(12).get("autoProctorSensorID").toString(), useGlobalSensorId);
            Assert.assertEquals(responseArray.getJSONObject(12).get("onVueSessionID").toString(), "37621");
            Assert.assertEquals(responseArray.getJSONObject(12).get("registrationID").toString(), reservationAsString);
            Assert.assertEquals(responseArray.getJSONObject(12).get("sensorEventType").toString(), "MULTI_FACE");
            Assert.assertEquals(responseArray.getJSONObject(12).get("sensorEventStatus").toString(), "STOPPED");
            // Sensor aborted
            Assert.assertEquals(responseArray.getJSONObject(13).get("sensorEventLogType").toString(), "SENSOR_NOTIFICATION");
            Assert.assertEquals(responseArray.getJSONObject(13).get("autoProctorSensorID").toString(), useGlobalSensorId);
            Assert.assertEquals(responseArray.getJSONObject(13).get("onVueSessionID").toString(), "37621");
            Assert.assertEquals(responseArray.getJSONObject(13).get("registrationID").toString(), reservationAsString);
            Assert.assertEquals(responseArray.getJSONObject(13).get("sensorEventType").toString(), "NOTIFICATION");
            Assert.assertEquals(responseArray.getJSONObject(13).get("sensorEventCode").toString(), "102");
            Assert.assertEquals(responseArray.getJSONObject(13).get("sensorEventLevel").toString(), "ERROR");
            // Stop Event generated even when sensor paused
            Assert.assertEquals(responseArray.getJSONObject(15).get("sensorEventLogType").toString(), "SENSOR_EVENT");
            Assert.assertEquals(responseArray.getJSONObject(15).get("autoProctorSensorID").toString(), useGlobalSensorId);
            Assert.assertEquals(responseArray.getJSONObject(15).get("onVueSessionID").toString(), "37621");
            Assert.assertEquals(responseArray.getJSONObject(15).get("registrationID").toString(), reservationAsString);
            Assert.assertEquals(responseArray.getJSONObject(15).get("sensorEventType").toString(), "MULTI_FACE");
            Assert.assertEquals(responseArray.getJSONObject(15).get("sensorEventStatus").toString(), "STOPPED");
        } catch (AssertionError | InterruptedException e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }


    // end exam with invalid URL and get response with status code 404
    @Test
    public void endExam_Validation_with_Failure_404() {
        try {
            RequestSpecification endExamResBody = given().spec(getAccessToken).body(endExamPayload.Payload());
            Response endExamResponse = endExamResBody.when().post("/rest/exam/end11").
                    then().extract().response();
            String responseString = endExamResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(endExamResponse.getStatusCode(), 404);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }


    // launch sensor API with Invalid sensor id with status code 400
    @Test
    public void launch_Sensor_event_Invalid_success_400() {
        try {
            RequestSpecification sensorEventBody = given().spec(getAccessToken).body(invalidSensorIdPayload.Payload());
            Response sensorEventInvalidResponse = sensorEventBody.when().post("/rest/sensor/event/").
                    then().extract().response();
            JSONArray responseString = new JSONArray(sensorEventInvalidResponse.asString());
            System.out.println(responseString);
            Assert.assertEquals(sensorEventInvalidResponse.getStatusCode(), 400);

            System.out.println(responseString.length());
            Assert.assertEquals(responseString.length(), 1);
            Assert.assertEquals(responseString.getJSONObject(0).get("code").toString(), "error.invalidSensorID");
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    // post to notification with invalid input
    @Test
    public void post_notification_invalid_attribute_expect_Bad_Request_400() {
        try {
            String invalidPayload = notificationPayload.Payload().replace("Id", "ID11");
            RequestSpecification notificationRequest = given().spec(getAccessToken).body(invalidPayload);
            Response notificationResponse = notificationRequest.when().post("/rest/sensor/notification").
                    then().extract().response();
            String responseString = notificationResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(notificationResponse.getStatusCode(), 400);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    // Get 204 response code message when session table record entry using Invalid reservation id and session id
    @Test
    public void sessionTableValidation_with_success_204() {
        try {
            Response sessionResponse = given().spec(getAccessToken).contentType(ContentType.JSON).when().get(sessionTableURL + "Automation2222")
                    .then()
                    .extract()
                    .response();
            String responseString = sessionResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(sessionResponse.getStatusCode(), 204);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    //Negative test to validate 404 error code for start exam
    @Test
    public void startExam_Validation_with_Failure_404() {
        try {
            RequestSpecification startExamResBody = given().spec(getAccessToken).body(startExamPayload.Payload());
            Response endExamResponse = startExamResBody.when().post("/rest/exam/start111").
                    then().extract().response();
            String responseString = endExamResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(endExamResponse.getStatusCode(), 404);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    //Negative test for CAS token
    @Test
    public void token_Validation_with_Failure_401() {
        try {
            //Unauthorized access - Invalid client secret
            Response resp = given().spec(getAccessToken)
                    .formParam("client_id", getClientId())
                    .formParam("client_secret", getclientSecret())
                    .formParam("grant_type", getgrantType())
                    .post(getcasToken());
            token = resp.jsonPath().get("access_token");
            Assert.assertEquals(resp.getStatusCode(), 401);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }


    //Verify valid client has not configured with face and item sensor for APS-automation client then, sensors should not launch.
    @Test
    public void client_configurationTest_APS_automation_noConfiguration() {
        try {
            RequestSpecification blacklistClientRequestBody = given().spec(getAccessToken).body(startExamWithNoClientcodeConfigured.Payload());
            Response blacklistClientResponse = blacklistClientRequestBody.when().post("/rest/exam/start").
                    then().extract().response();
            String responseString = blacklistClientResponse.asString();
            System.out.println(responseString);
            reservationAsString1 = startExamWithNoClientcodeConfigured.reservation1.toString();
            System.out.println("The reservation id fo invalid client is : " + reservationAsString1);
            Assert.assertEquals(blacklistClientResponse.getStatusCode(), 200);

            Thread.sleep(10000);
            // call reservation id from start exam Payload
            // User called reservation id to fetch the Get API
            Response sessionResponse1 = given().spec(getAccessToken).contentType(ContentType.JSON).when().get(sessionTableURL + reservationAsString1)
                    .then()
                    .extract()
                    .response();
            String responseString1 = sessionResponse1.asString();
            System.out.println(responseString1);
            // As there is no sensor launched for that reservation id , while trying to fetch the record using reservation id , we are getting 204 as no record found .
            Assert.assertEquals(sessionResponse1.getStatusCode(), 204);
        } catch (AssertionError | InterruptedException e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    //Verify valid client has not configured with face and item sensor for APS-automation client then, sensors should not launch.
    @Test
    public void client_configurationTest_APS_automation_noConfiguration_endExam() {
        try {
            RequestSpecification endExamResBody = given().spec(getAccessToken).body(endExamInvalidClient.Payload());
            Response endExamResponse = endExamResBody.when().post("/rest/exam/end").
                    then().extract().response();
            String responseString = endExamResponse.asString();
            System.out.println(responseString);
            Assert.assertEquals(endExamResponse.getStatusCode(), 200);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }
}
