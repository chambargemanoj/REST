package com.autoproctor.test.files;

import java.util.UUID;

public class startExamWithNoClientcodeConfigured {
    public static UUID reservation1 = UUID.randomUUID();

    public static String ReservationIDInvalidClient() {
        String reservationAsString1;
        reservationAsString1 = reservation1.toString();
        return reservationAsString1;
    }

    public static String Payload() {
        return "{\n" +
                "   \"reservationId\":\"" + ReservationIDInvalidClient() + "\",\n" +
                "\t\"onVueSessionId\": 37621,\n" +
                "\t\"examStartTime\": \"009800\",\n" +
                "\t\"examSeriesCode\": \"ABC\",\n" +
                "\t\"clientCode\": \"APSAutomation\",\n" +
                "\t\"wowzaStream\": {\n" +
                "\t\t\"webRtc256\": \"URL1\",\n" +
                "\t\t\"webRtcStreamName\": \"9aea40ce_stream1\",\n" +
                "\t\t\"webRtcApplicationName\": \"app-b43X3PBH\",\n" +
                "\t\t\"hls64\": \"URL2\",\n" +
                "\t\t\"hls256\": \"URL3\"\n" +
                "\t},\n" +
                "\t\"accommodations\": [{\n" +
                "\t\t\"typeCode\": \"ONVUEC\"\n" +
                "\t}, {\n" +
                "\t\t\"typeCode\": \"ONVUEH\"\n" +
                "\t}],\n" +
                "\t\"candidate\": {\n" +
                "\t\t\"clientCandidateId\": \"SampleID\",\n" +
                "\t\t\"demographics\": {\n" +
                "\t\t\t\"state\": \"MN\",\n" +
                "\t\t\t\"country\": \"USA\"\n" +
                "\t\t},\n" +
                "\t\t\"machineCapability\": {\n" +
                "\t\t\t\"cpu\": \"64000\",\n" +
                "\t\t\t\"ram\": \"34523\"\n" +
                "\t\t},\n" +
                "\t\t\"aiInfo\": {\n" +
                "\t\t\t\"optOut\": true\n" +
                "\t\t}\n" +
                "\t},\n" +
                "\t\"examDuration\": 45,\n" +
                "\t\"allowances\": [{\n" +
                "\t\t\"typeCode\": \"ONVUEC\"\n" +
                "\t}, {\n" +
                "\t\t\"typeCode\": \"ONVUEH\"\n" +
                "\t}]\n" +
                "}";
    }

}
