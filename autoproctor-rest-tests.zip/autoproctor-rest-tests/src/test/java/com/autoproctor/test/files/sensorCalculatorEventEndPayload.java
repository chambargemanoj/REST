package com.autoproctor.test.files;

import com.autoproctor.test.validation.StartAndEndExamTest;

public class sensorCalculatorEventEndPayload {


    public static  String  Payload () {
        String sensorIDCopy;
        sensorIDCopy = StartAndEndExamTest.useItemSensorId;
        return "{\n" +
                "    \"sensorId\": \""+sensorIDCopy+"\",\n" +
                "    \"eventTime\": 160795501000,\n" +
                "    \"eventType\": \"CALCULATOR\",\n" +
                "    \"status\": \"STOPPED\",\n" +
                "    \"confidence\": 0.72,\n" +
                "    \"eventData\": [\n" +
                "        {\n" +
                "            \"id\": \"SampExamId\",\n" +
                "            \"value\": \"SampTEST123\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"id\": \"Candidate_Name\",\n" +
                "            \"value\": \"Sampxyz123\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
    }
}
