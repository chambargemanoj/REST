package com.autoproctor.test.files;

import com.autoproctor.test.validation.StartAndEndExamTest;

public class sensorMultiFaceEventStartPayload {
    public static  String  Payload () {
        String sensorIDCopy;
        sensorIDCopy = StartAndEndExamTest.useGlobalSensorId;
        return "{\n" +
                "    \"sensorId\": \""+sensorIDCopy+"\",\n" +
                "    \"eventTime\": 160795507000,\n" +
                "    \"eventType\": \"MULTI_FACE\",\n" +
                "    \"status\": \"STARTED\",\n" +
                "    \"confidence\": 0.72,\n" +
                "    \"eventData\": [\n" +
                "        {\n" +
                "            \"id\": \"SampExamId\",\n" +
                "            \"value\": \"SampTEST123\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"id\": \"Candidate_Name\",\n" +
                "            \"value\": \"Sampxyz123\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
    }
}
