package com.autoproctor.test.service;

import com.autoproctor.test.config.APSConfig;
import com.autoproctor.test.files.notificationPayload;
import com.autoproctor.test.files.startExamPayload;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.oauth2;
import static io.restassured.RestAssured.requestSpecification;

public class APSService {

    APSConfig apsConfig;
    String token;
    RequestSpecification startExamRequest;
    RequestSpecification endExamRequest;
    RequestSpecification requestSpecification;
    RequestSpecification notificationRequest;
    RequestSpecification getSessionRequest;
    RequestSpecification sensorEventRequest;
    RequestSpecification sensorEventLaunchAckRequest;
    RequestSpecification sensorEventShutdownAckRequest;
    RequestSpecification sensorPauseEventRequest;
    RequestSpecification sensorResumeEventRequest;
    RequestSpecification sensorMuteEventRequest;
    RequestSpecification sensorunMuteEventRequest;
    RequestSpecification backendSensor_102_Request;
    RequestSpecification backendSensor_101_Request;
    RequestSpecification blacklistClientRequest;


    Response notificationResponse;
    Response getSessionResponse;

    String endpoint = "/rest/sensor/notification";

    public APSService(APSConfig apsConfig, String token) {
        this.apsConfig = apsConfig;
        this.token = token;
        init();
    }

    public  void init(){
        // set up to run start exam request api
        startExamRequest = new RequestSpecBuilder().setBaseUri(apsConfig.getbaseUrl())
                .setAuth(oauth2(token)).setContentType("application/json").build();

        // set up to run endexam request api
        endExamRequest = new RequestSpecBuilder().setBaseUri(apsConfig.getbaseUrl())
                .setAuth(oauth2(token)).setContentType("application/json").build();

        // set up to run endexam request api
        requestSpecification = new RequestSpecBuilder().setBaseUri(apsConfig.getbaseUrl())
                .setAuth(oauth2(token)).setContentType("application/json").build();

        // set up to run notification proctor api
        notificationRequest = given().spec(requestSpecification).body(notificationPayload.Payload());
        notificationResponse = notificationRequest.when().post("/rest/sensor/notification").
                then().extract().response();

        // get a sessionId in order to get a valid sensorId
        getSessionRequest = given().spec(requestSpecification).body(notificationPayload.Payload());
        getSessionResponse = notificationRequest.when().post("/rest/session?onVueSessionId=012").
                then().extract().response();
        String sensorId = getSessionResponse.jsonPath().get("sensorId");

        // set up to run sensor event api
        sensorEventRequest = new RequestSpecBuilder().setBaseUri(apsConfig.getbaseUrl())
                .setAuth(oauth2(token)).setContentType("application/json").build();

        // set up to run Sensor Launch Acknowledgement api
        sensorEventLaunchAckRequest = new RequestSpecBuilder().setBaseUri(apsConfig.getbaseUrl())
                .setAuth(oauth2(token)).setContentType("application/json").build();

        // set up to run Sensor Shutdown Acknowledgement  api
        sensorEventShutdownAckRequest = new RequestSpecBuilder().setBaseUri(apsConfig.getbaseUrl())
                .setAuth(oauth2(token)).setContentType("application/json").build();

        // set up to Pause Sensor when exam already started
        sensorPauseEventRequest = new RequestSpecBuilder().setBaseUri(apsConfig.getbaseUrl())
                .setAuth(oauth2(token)).setContentType("application/json").build();

        // set up to Resume Sensor when exam already started
        sensorResumeEventRequest = new RequestSpecBuilder().setBaseUri(apsConfig.getbaseUrl())
                .setAuth(oauth2(token)).setContentType("application/json").build();

        // set up to Mute Sensor when exam already started
        sensorMuteEventRequest = new RequestSpecBuilder().setBaseUri(apsConfig.getbaseUrl())
                .setAuth(oauth2(token)).setContentType("application/json").build();

        // set up to unMute Sensor when exam already started
        sensorunMuteEventRequest = new RequestSpecBuilder().setBaseUri(apsConfig.getbaseUrl())
                .setAuth(oauth2(token)).setContentType("application/json").build();

        // set up to launch back end sensor when error code 102 received.
        backendSensor_102_Request = new RequestSpecBuilder().setBaseUri(apsConfig.getbaseUrl())
                .setAuth(oauth2(token)).setContentType("application/json").build();

        // set up to launch back end sensor when error code 101 received.
        backendSensor_101_Request = new RequestSpecBuilder().setBaseUri(apsConfig.getbaseUrl())
                .setAuth(oauth2(token)).setContentType("application/json").build();

        // set up to launch back end sensor when error code 101 received.
        blacklistClientRequest = new RequestSpecBuilder().setBaseUri(apsConfig.getbaseUrl())
                .setAuth(oauth2(token)).setContentType("application/json").build();
    }

    public Response startExam(String payload){
        RequestSpecification startExamres1 = given().spec(startExamRequest).body(payload);
        Response startExamresponse = startExamres1.when().post("/rest/exam/start").
                then().extract().response();
        return startExamresponse;
    }

    public String notification(String validSensorId){
        notificationRequest = given().spec(requestSpecification).body(validSensorId);
        notificationResponse = notificationRequest.when().post(endpoint).
                then().extract().response();
        String responseString = notificationResponse.asString();
        System.out.println(responseString);
        return responseString;
    }

}
