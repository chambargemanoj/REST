package com.autoproctor.test.files;

import com.autoproctor.test.validation.StartAndEndExamTest;

public class shutdownAckPayload {
    public static  String  Payload () {
        String sensorIDCopy;
        sensorIDCopy = StartAndEndExamTest.useItemSensorId;
        return "{\n" +
                "    \"sensorId\": \""+sensorIDCopy+"\",\n" +
                "\"status\":\"SUCCESS\"\n" +
                "}";
    }
}
