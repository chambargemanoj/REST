package com.autoproctor.test.files;
public class sensorResumePayload {
    public static String Payload() {
        String reservationAsString;
        reservationAsString = startExamPayload.reservation.toString();
         return "{\n" +
                 "   \"reservationId\":\"" + reservationAsString + "\",\n" +
                "   \"onVueSessionId\": 999,\n" +
                "   \"examSeriesCode\": \"SERIES\",\n" +
                "   \"clientCode\": \"HEWPACK\",\n" +
                "   \"state\": \"RESUME\"\n" +
                "}";
    }
}
