package com.autoproctor.test.files;

import com.autoproctor.test.validation.StartAndEndExamTest;

public class notificationPayload {
    private notificationPayload() {
    }

    public static  String  Payload () {
        final String sensorIDCopy = StartAndEndExamTest.useGlobalSensorId;
        return "{\n" +
                "    \"sensorId\": \""+sensorIDCopy+"\",\n" +
                "   \"eventTime\":1616004466,\n" +
                "   \"notificationLevel\":\"INFO\",\n" +
                "   \"code\":\"200\",\n" +
                "   \"description\":\"message\",\n" +
                "   \"data\":[{\n" +
                "    \"id\":\"FrameResolution\",\n" +
                "    \"value\":\"sampleRes\"\n" +
                "   }]\n" +
                "}";
    }
}
