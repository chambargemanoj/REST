package utility;

import java.io.IOException;
import java.util.Properties;

public class PropertyConfigUtil {
    private Properties properties;

    /**
     * Get the property value
     *
     * @param key Property key
     * @return The value assigned to the key
     */
    public String getPropertyValue(String key) {
        return properties.getProperty(key);
    }

    /**
     * Load the the property file found in resources
     */
    public void loadPropertyFile(String resourcePath) {
        try {
            properties = new Properties();
            properties.load(getClass().getClassLoader().getResourceAsStream(resourcePath));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}